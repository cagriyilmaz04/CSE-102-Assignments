/*
** hw5_lib.c:
**
** The source file implementing library functions.
**
** Author: Yakup Genc. (c) 2018-2021
**
** Revision: 2021.04.02.23.55
** 
*/

#include <stdio.h>
#include <math.h>
#include "hw5_lib.h"
#define PI 3.141592654

void swap(char *a, char *b){
	char temp = *a;
	*a = *b;
	*b = temp;
}
void swap_d(double *a, double *b){
	double temp = *a;
	*a = *b;
	*b = temp;
}

int order(double *a, double *b)
{
    double inter;

    if(*a >= *(b))
    {
        inter = (*a);
        *a = (*b);
        *b = inter;
		return 1;
	}

	return 0;
}

double find_third_sides(double *x1,double *y1){
	double b;
    b=sqrt(((*x1)*(*x1))+((*y1)*(*y1)));
    return b;
}

double find_angle(double *s){
 	double i;
 	for(i=0;i<90;i+=0.01){
        if(fabs(sin(i*(PI/180))-(*s))<=0.00001){
            printf("\nYii %lf\n",i);
            break;
        }
    }
    return i;
}
int find_area(double *x,double *y){
    int flag=0;
    if(*x>0&&*y>0){
        flag=1;
    }else if(*x<0&&*y>0){
        flag=2;
    }else if(*x<0&&*y<0){
        flag=3;
    }else if(*x>0&&*y<0){
        flag=4;
    }
    return flag;
}

int binary_to_decimal(char c,int pw){
	if(c=='0') return 0;
	else if(c=='1') return pow(2,pw);
}

double find_max(double *a,double*b,double *c,double *d,double *e){
    double flag=0;
    if(*a>=*b&&*a>=*c&&*a>=*d&&*a>=*e){
        flag =(*a);
    }else if(*b>=*a&&*b>=*c&&*b>=*d&&*b>=*e){
        flag =(*b);
    }else if(*c>=*a&&*c>=*b&&*c>=*d&&*c>=*e){
        flag =(*c);
    }
    else if(*d>=*a&&*d>=*c&&*d>=*b&&*d>=*e){
        flag =(*d);
    }
    else if(*e>=*a&&*e>=*b&&*e>=*c&&*e>=*d){
        flag =(*e);
    }
    return flag;
}



void operate_polynomials  (double* a3, double* a2, double* a1, double* a0, double* b3, double* b2, double* b1, double* b0, char op)
{
	int katsayi,katsay1,katsayi2,katsayi3,katsayi4,katsayi5,katsayi6,katsayi7;
    double result,result1,result2,result3;
	double resultx3,resultx2,resultx1,resultx0;
    double toplanacak3,toplanacak2,toplanacak1,toplanacak0;
    double toplanacak4,toplanacak5,toplanacak6,toplanacak7;
    int c1=1,c2=2,c3=3,c0=0;
    printf("Enter First equation\n");
     while(scanf(" %d %lf %d %lf %d %lf %d %lf",&katsayi,a0,&katsay1,a1,&katsayi2,a2,&katsayi3,a3)!=8||(katsayi<0||katsay1<0||katsayi2<0||katsayi3<0)){
			while(getchar()!='\n');
        printf("Enter numeric number\n");
    }
    printf("Enter second equation\n");
    while(scanf("%d %lf %d %lf %d %lf %d %lf",&katsayi4,b0,&katsayi5,b1,&katsayi6,b2,&katsayi7,b3)!=8||(katsayi4<0||katsayi5<0||katsayi6<0||katsayi7<0)){
        while(getchar()!='\n');
        printf("Enter numeric number\n");

    }
    printf("Enter your operator\n");
      while(scanf(" %c",&op)!=1){
			while(getchar()!='\n');
        printf("Enter Correct Operation (+,-,*)\n");
    }
    
    switch(katsayi){
    case 3:

        toplanacak3=(*a0);
        break;
    case 2:

        toplanacak2=(*a0);
        break;
    case 1:

        toplanacak1=(*a0);
        break;
    case 0:

        toplanacak0=(*a0);
        break;
    }
    switch(katsay1){

    case 3:

        toplanacak3=(*a1);
        break;
    case 2:

        toplanacak2=(*a1);
        break;
    case 1:

        toplanacak1=(*a1);
        break;
    case 0:

        toplanacak0=(*a1);
        break;
    }
    switch(katsayi2){
    case 3:


        toplanacak3=(*a2);
        break;
    case 2:

        toplanacak2=(*a2);
        break;
    case 1:

        toplanacak1=(*a2);
        break;
    case 0:

        toplanacak0=(*a2);
        break;
    }
    switch(katsayi3){
    case 3:

        toplanacak3=(*a3);
        break;
    case 2:

        toplanacak2=(*a3);
        break;
    case 1:

       toplanacak1=(*a3);
        break;
    case 0:

        toplanacak0=(*a3);
        break;
    }

     switch(katsayi4){

    case 3:

        toplanacak7=(*b0);
        break;
    case 2:

        toplanacak6=(*b0);
        break;
    case 1:

        toplanacak5=(*b0);
        break;
    case 0:

        toplanacak4=(*b0);
        break;
    }
    switch(katsayi5){
    case 3:

        toplanacak7=(*b1);
        break;
    case 2:

        toplanacak6=(*b1);
        break;
    case 1:

        toplanacak5=(*b1);
        break;
    case 0:

        toplanacak4=(*b1);
        break;
    }

    switch(katsayi6){
    case 3:

        toplanacak7=(*b2);
        break;
    case 2:

        toplanacak6=(*b2);
        break;
    case 1:

        toplanacak5=(*b2);
        break;
    case 0:

        toplanacak4=(*b2);
        break;
    }
    switch(katsayi7){
    case 3:

        toplanacak7=(*b3);
        break;
    case 2:

        toplanacak6=(*b3);
        break;
    case 1:
        toplanacak5=(*b3);
        break;
    case 0:
        toplanacak4=(*b3);
        break;
    }


    switch(op){
    case '+':
        result=toplanacak0+toplanacak4;
        result1=toplanacak1+toplanacak5;
        result2=toplanacak2+toplanacak6;
        result3=toplanacak3+toplanacak7;
        printf("(%d %.2lf) (%d %.2lf) (%d %.2lf) (%d %.2lf)\n",c0,result,c1,result1,c2,result2,c3,result3);
        break;
    case '-':
        result=toplanacak0-toplanacak4;
        result1=toplanacak1-toplanacak5;
        result2=toplanacak2-toplanacak6;
        result3=toplanacak3-toplanacak7;
         printf("(%d %.2lf) (%d %.2lf) (%d %.2lf) (%d %.2lf)\n",c0,result,c1,result1,c2,result2,c3,result3);
        break;
    case '*':
         result=toplanacak0*toplanacak4;
        result1=toplanacak1*toplanacak5;
        result2=toplanacak2*toplanacak6;
        result3=toplanacak3*toplanacak7;
         printf("(%d %.2lf) (%d %.2lf) (%d %.2lf) (%d %.2lf)\n",c0,result,c1,result1,c2,result2,c3,result3);
        break;
    default:
        printf("You can make addition subtraction and multiplication\n");
    }
}


void four_d_vectors (double* mean_a0, double* mean_a1, double* mean_a2, double* mean_a3, double* longest_distance, int N)
{
	/*In this part when you enter -1 -1 -1 -1 that means our last vector is -1 -1 -1 -1 */
	double d0, d1, d2, d3, euclidian_distance;
	double temp;
	double a_d0=0,a_d1=0,a_d2=0,a_d3=0;
	double a0,a1,a2,a3;
	int count=0;
	double max=-1;
	int i=1;
	
	  while(i<=N){
                 printf("Enter First Coordinate\n");
         while(scanf("%lf",mean_a0)!=1){
			while(getchar()!='\n');
        printf("Enter numeric number\n");
    }
          printf("Enter Second Coordinate\n");
         while(scanf("%lf",mean_a1)!=1){
			while(getchar()!='\n');
        printf("Enter numeric number\n");
    }
        printf("Enter Third Coordinate\n");
         while(scanf("%lf",mean_a2)!=1){
			while(getchar()!='\n');
        printf("Enter numeric number\n");
    }
        printf("Enter Fourth Coordinate\n");
         while(scanf("%lf",mean_a3)!=1){
			while(getchar()!='\n');
        printf("Enter numeric number\n");
    }
        if((*mean_a0)!=-1&&(*mean_a1)!=-1&&(*mean_a2)!=-1&&(*mean_a3)!=-1){
            if(i==1){
        a0=*mean_a0;
        a1=*mean_a1;
        a2=*mean_a2;
        a3=*mean_a3;
        a_d0+=*mean_a0;
        a_d1+=*mean_a1;
        a_d2+=*mean_a2;
        a_d3+=*mean_a3;
      }
      if(i>1){
           *mean_a0=*mean_a0-a0;
            *mean_a1=*mean_a1-a1;
            *mean_a2=*mean_a2-a2;
            *mean_a3=*mean_a3-a3;
        distance_between_4d_points(*mean_a0, *mean_a1, *mean_a2,*mean_a3,&euclidian_distance);
        if(euclidian_distance>max){
        *longest_distance=euclidian_distance;
        max=euclidian_distance;
      }
        a0+=*mean_a0;
        a1+=*mean_a1;
        a2+=*mean_a2;
        a3+=*mean_a3;
         a_d0+=a0;
         a_d1+=a1;
         a_d2+=a2;
         a_d3+=a3;
      }
        }else if((*mean_a0)==-1&&(*mean_a1)==-1&&(*mean_a2)==-1&&(*mean_a3)==-1){
                    d0=-1;
                    d1=-1;
                    d2=-1;
                    d3=-1;
                    a_d0+=d0;
                    a_d1+=d1;
                    a_d2+=d2;
                    a_d3+=d3;
                distance_between_4d_points (a0-d0, a1-d1, a2-d2, a3-d3, &euclidian_distance);
                if(euclidian_distance-temp>max){
        *longest_distance=euclidian_distance;
        max=euclidian_distance;
      }
		printf("Temp %lf Oklit %lf Longest %lf\n",temp,euclidian_distance,*longest_distance);
						break;
					}
					*longest_distance=max;
				i++;
			}
		printf("%lf\n",*longest_distance);
		if(i>N){
			i=N;
		}
			printf("\nAverage %.2lf %.2lf %.2lf %.2lf\n",a_d0/i,a_d1/i,a_d2/i,a_d3/i);
}


void distance_between_4d_points (double d0, double d1, double d2, double d3, double* euclidian_distance)
{
    *euclidian_distance=sqrt(pow((d0),2)+pow((d1),2)+pow((d2),2)+pow((d3),2));
	printf("%.4lf\n",*euclidian_distance);
}


void dhondt_method (int* partyA, int* partyB, int* partyC, int* partyD, int* partyE, int numberOfSeats)
{
	 int seatA=0,seatB=0,seatC=0,seatD=0,seatE=0;
        int count1=1,count2=1,count3=1,count4=1,count=1;
       
        int temp;
        double partyAd,partyBd,partyCd,partyDd,partyEd;
        partyAd=(*partyA);
        partyBd=(*partyB);
        partyCd=(*partyC);
        partyDd=(*partyD);
        partyEd=(*partyE);
        while(numberOfSeats>(seatA+seatB+seatC+seatD+seatE)){
            double a=find_max(&partyAd,&partyBd,&partyCd,&partyDd,&partyEd);
        if(a==(partyAd)){

            temp=count1;
            seatA++;
            partyAd=(partyAd)*count1;
            count1++;
            partyAd=(partyAd)/count1;

        }else if(a==(partyBd)){
            temp=count2;
            seatB++;
    partyBd=(partyBd)*count2;

            count2++;

            partyBd=(partyBd)/count2;
        }else if(a==(partyCd)){
             temp=count3;
             seatC++;
            partyCd=(partyCd)*count3;

            count3++;

            partyCd=(partyCd)/count3;
        }else if(a==(partyDd)){
            temp=count4;
            seatD++;
            partyDd=(partyDd)*count4;

            count4++;

            partyDd=(partyDd)/count4;
        }else if(a==(*partyE)){
           temp=count;
            seatE++;
            partyEd=(partyEd)*count;

            count++;

            (partyEd)=(partyEd)/count;
        }

        }
    printf("**************DHONT METHOD****************\n");
    printf("\nParty A: %d seat(s)\n",seatA);
    printf("Party B: %d seat(s)\n",seatB);
    printf("Party C: %d seat(s)\n",seatC);
    printf("Party D: %d seat(s)\n",seatD);
    printf("Party E: %d seat(s)\n",seatE);

}


void order_2d_points_cc (double* x1, double* y1, double* x2, double* y2, double* x3, double* y3)
{
		double i,b,c,s,a1,b1,c1,s1,a2,b2,c2,s2,a3;
		int a;
		b=find_third_sides(x1,y1);
		b=sqrt(((*x1)*(*x1))+(*(y1)*(*y1)));

		c=(((*x1)*(*x1))+(b*b)-((*y1)*(*y1)))/((2*(*x1)*b));
		s=1*1-(c*c);
		s=sqrt(s);
		a1=find_angle(&s);
		a=find_area(x1,y1);
		switch(a){
		case 1:
		a1=(a*90)-a1;
		break;
		case 2:
			a1=(a*90)-a1;
			break;
		case 3:
			a1=(a*90)-a1;
			break;
			case 4:
			a1=(a*90)-a1;
			break;
			default:
				a1=0;
		}
	 b1=find_third_sides(x2,y2);
	 c1=(((*x2)*(*x2))+(b1*b1)-((*y2)*(*y2)))/((2*(*x2)*b1));
		 s1=1*1-(c1*c1);
		s1=sqrt(s1);
		 a2=find_angle(&s1);
		a=find_area(x2,y2);
		switch(a){
		case 1:
		a2=(a*90)-a2;
		break;
		case 2:
			a2=(a*90)-a2;
			break;
		case 3:
			a2=(a*90)-a2;
			break;
			case 4:
			a2=(a*90)-a2;
			break;
			default:
				a2=0;
		}



	 b2=find_third_sides(x3,y3);
	 c2=(((*x3)*(*x3))+(b2*b2)-((*y3)*(*y3)))/((2*(*x3)*b2));
	 s2=1*1-(c2*c2);
	s2=sqrt(s2);
	 a3=find_angle(&s2);
	a=find_area(x3,y3);
	switch(a){
	case 1:
			a3=(1*90)-a3;
		break;
	case 2:
			a3=(2*90)-a3;
		break;
	case 3:
			a3=(3*90)-a3;
		break;
	case 4:
			a3=(4*90)-a3;
	break;
		default: a3=0;
	}

	printf("%lf %lf %lf\n",a1,a2,a3);
	
	if(order(&a1,&a2)){
		swap_d(x1,x2);
		swap_d(y1,y2);
	}
	if(order(&a1,&a3)){
		swap_d(x1,x3);
		swap_d(y1,y3);
	}
	if(order(&a2,&a3)){
		swap_d(x2,x3);
		swap_d(y2,y3);
	}
	printf("%lf %lf %lf\n",a1,a2,a3);
}


void number_encrypt (unsigned char* number)
{
	char b7='-', b6='-', b5='-', b4='-', b3='-', b2='-', b1='-', b0='-';
	get_number_components (*number, &b7, &b6, &b5, &b4, &b3, &b2, &b1, &b0);
	reconstruct_components (number, b7, b6, b5, b4, b3, b2, b1, b0);
}


void get_number_components (unsigned char number, char* b7, char* b6, char* b5, char* b4, char* b3, char* b2, char* b1, char* b0)
{
	int a = (int)number,cr = 0;;
	*b7='0';*b6='0';*b5='0';*b4='0';*b3='0';*b2='0';*b1='0';*b0='0';
	while(a > 0){
		if(cr == 0){
			*b0 = a%2==0?'0':'1';
		}else if(cr == 1){
			*b1 = a%2==0?'0':'1';
		}else if(cr == 2){
			*b2 = a%2==0?'0':'1';
		}else if(cr == 3){
			*b3 = a%2==0?'0':'1';
		}else if(cr == 4){
			*b4 = a%2==0?'0':'1';
		}else if(cr == 5){
			*b5 = a%2==0?'0':'1';
		}else if(cr == 6){
			*b6 = a%2==0?'0':'1';
		}else if(cr == 7){
			*b7 = a%2==0?'0':'1';
		}
		a/=2;
		cr++;
	}
}


void reconstruct_components (unsigned char* number, char b7, char b6, char b5, char b4, char b3, char b2, char b1, char b0)
{
	int decimal;
	char tempB7,tempB6;
    swap(&b7,&b2);
	swap(&b6,&b3);
	swap(&b5,&b0);
	swap(&b4,&b1);
    tempB7=b7;
    tempB6=b6;
    swap(&b5,&b7);
    swap(&b4,&b6);
    swap(&b3,&b5);
    swap(&b2,&b4);
    swap(&b1,&b3);
    swap(&b0,&b2);
    b1=tempB7;
    b0=tempB6;
	decimal=binary_to_decimal(b7,7)+binary_to_decimal(b6,6)+binary_to_decimal(b5,5)+binary_to_decimal(b4,4)+binary_to_decimal(b3,3)+binary_to_decimal(b2,2)+binary_to_decimal(b1,1)+binary_to_decimal(b0,0);
	*number=decimal;
}
